-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 30, 2019 at 06:48 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tta`
--

-- --------------------------------------------------------

--
-- Table structure for table `driverinfo`
--

CREATE TABLE `driverinfo` (
  `Driver_ID` int(11) NOT NULL,
  `Company_ID` int(11) NOT NULL,
  `Driver_Name` varchar(30) NOT NULL,
  `Driver_Mail_ID` varchar(30) NOT NULL,
  `Driver_Password` varchar(30) NOT NULL,
  `Driver_Phone` varchar(30) NOT NULL,
  `Driver_NID` varchar(40) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Driver_Approval` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driverinfo`
--

INSERT INTO `driverinfo` (`Driver_ID`, `Company_ID`, `Driver_Name`, `Driver_Mail_ID`, `Driver_Password`, `Driver_Phone`, `Driver_NID`, `Location`, `Driver_Approval`) VALUES
(1, 24, 'Arif', 'Arif@gmail.com', '23456', '01682485219', '0101010101010', '24.3668802 & 88.6258481', 'Yes'),
(2, 24, 'shoib', 'mnzshoib@gmail.com', '2543', '01521334705', '23456786543', '24.3703 & 88.6029', 'Yes'),
(3, 25, 'kazi', 'kazi@gmail.com', '3344', '01521334718', '23232323', '24.3744 & 88.6078', 'Yes'),
(4, 24, 'bulbul', 'bulbul@gmail.com', '34567', '0121212120', '123444444', '24.3725 & 88.6030', 'Yes'),
(5, 24, 'apu', 'apu@gmail.com', '3567', '0211314150', '456444444', '24.3725 & 88.6030', 'Yes'),
(6, 24, 'abir', 'abir@gmail.com', '3654', '015000000', '0192837465', '', 'No'),
(7, 24, 'zahid', 'zahid@gmail.com', '3645', '012882737', '0120804836768792', '', 'No'),
(11, 24, 'tutul', 'tutul@gmail.com', '3645', '12901239023', '01208048367687924', '', 'No'),
(12, 24, 'onik', 'onik@gmail.com', '2324', '2342342342', '45654767867453', '', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `logininfo`
--

CREATE TABLE `logininfo` (
  `id` int(11) NOT NULL,
  `mail_id` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `PhoneNo` varchar(20) NOT NULL,
  `NIDNo` varchar(30) NOT NULL,
  `category` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logininfo`
--

INSERT INTO `logininfo` (`id`, `mail_id`, `username`, `password`, `PhoneNo`, `NIDNo`, `category`) VALUES
(1, 'jakhos97@gmail.com', 'jakir', '1234', '01521334719', '01000000100010', 'admin'),
(3, 'abc@gmail.com', 'hello', '2345', '222222222', '222222222222222', 'user'),
(4, 'shams@gmail.com', 'shams', '2356', '11111111', '23232323232323', 'user'),
(5, 'tarek@gmail.com', 'tarek', '4567', '23232323', '23232323', 'user'),
(22, 'imambuet420@gmail.com', 'Imam Hossain', '2341', '01552929499', '2347886543267', 'admin'),
(23, 'mustak@gmail.com', 'mustak', '6789987', '5555555555', '23466489997665', 'user'),
(24, 'sagor@gmail.com', 'sagor', '45677', '01521300713', '346985432678', 'company'),
(25, 'asif@gmail.com', 'Asif', '2314', '121212121', '121212121212', 'company'),
(26, 'adib@gmail.com', 'Adib', '2314', '2121212121', '2121212121212', 'company');

-- --------------------------------------------------------

--
-- Table structure for table `roadmap`
--

CREATE TABLE `roadmap` (
  `id` int(11) NOT NULL,
  `start node` int(11) NOT NULL,
  `stop node` int(11) NOT NULL,
  `edge` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roadmap`
--

INSERT INTO `roadmap` (`id`, `start node`, `stop node`, `edge`) VALUES
(1, 11, 12, 1),
(2, 12, 13, 2),
(3, 12, 18, 3),
(4, 13, 26, 4),
(5, 13, 16, 5),
(6, 26, 14, 6),
(7, 26, 15, 7),
(8, 14, 25, 8),
(9, 25, 24, 9),
(10, 24, 23, 10),
(11, 23, 22, 11),
(12, 22, 21, 12),
(13, 21, 20, 13),
(14, 21, 15, 14),
(15, 20, 19, 15),
(16, 20, 16, 16),
(17, 19, 18, 17),
(18, 18, 16, 18),
(19, 16, 17, 19),
(20, 17, 15, 20),
(21, 1, 2, 21),
(22, 2, 3, 22),
(23, 3, 4, 23),
(24, 4, 5, 24),
(25, 5, 6, 25),
(26, 6, 7, 26),
(27, 7, 8, 27),
(28, 8, 9, 28),
(29, 9, 1, 29);

-- --------------------------------------------------------

--
-- Table structure for table `transportstand`
--

CREATE TABLE `transportstand` (
  `Stand_no` int(11) NOT NULL,
  `PlaceName` varchar(50) NOT NULL,
  `Latitude` double NOT NULL,
  `Longitude` double NOT NULL,
  `Division` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transportstand`
--

INSERT INTO `transportstand` (`Stand_no`, `PlaceName`, `Latitude`, `Longitude`, `Division`) VALUES
(1, 'mugda', 23.7295, 90.4285, 'Dhaka'),
(2, 'komlapur', 23.7285, 90.4254, 'Dhaka'),
(3, 'arambag', 23.7315, 90.421, 'Dhaka'),
(4, 'motijil', 23.7266, 90.4215, 'Dhaka'),
(5, 'polton', 23.7302, 90.4121, 'Dhaka'),
(6, 'kakrail', 23.7378, 90.4091, 'Dhaka'),
(7, 'malibag', 23.7438, 90.4143, 'Dhaka'),
(8, 'rajarBag', 23.7401, 90.42, 'Dhaka'),
(9, 'bashabo', 23.74, 90.4276, 'Dhaka'),
(10, 'buddho mondir', 23.7356, 90.4287, 'Dhaka'),
(11, 'ruet', 24.3626, 88.629, 'Rajshahi'),
(12, 'talaimari', 24.3616, 88.627, 'Rajshahi'),
(13, 'hadir mor', 24.3611, 88.6172, 'Rajshahi'),
(14, 'zero point', 24.3653, 88.6, 'Rajshahi'),
(15, 'sagor para bottola', 24.3671, 88.6069, 'Rajshahi'),
(16, 'sadur mor', 24.3665, 88.6189, 'Rajshahi'),
(17, 'tika para', 24.3658, 88.6113, 'Rajshahi'),
(18, 'northern mor', 24.3643, 88.6261, 'Rajshahi'),
(19, 'filling station', 24.3705, 88.6235, 'Rajshahi'),
(20, 'bodra', 24.3748, 88.622, 'Rajshahi'),
(21, 'railway station', 24.3744, 88.6078, 'Rajshahi'),
(22, 'railgate', 24.3744, 88.6042, 'Rajshahi'),
(23, 'new market', 24.3726, 88.603, 'Rajshahi'),
(24, 'aolokar mor', 24.3703, 88.6029, 'Rajshahi'),
(25, 'gonokpara', 24.3665, 88.6003, 'Rajshahi'),
(26, 'sagor para', 24.3628, 88.6056, 'Rajshahi');

-- --------------------------------------------------------

--
-- Table structure for table `transport_info`
--

CREATE TABLE `transport_info` (
  `id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `transport_name` varchar(50) NOT NULL,
  `license_no` varchar(50) NOT NULL,
  `road` varchar(200) NOT NULL,
  `driver_id` int(11) NOT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transport_info`
--

INSERT INTO `transport_info` (`id`, `company_id`, `transport_name`, `license_no`, `road`, `driver_id`, `status`) VALUES
(0, 24, 'Hanif', 'abcd', '12,13,26,14,25,24,23,22,21,15,17,16,18', 1, 'active'),
(2, 24, 'Desh Travels', 'acbde', '12,18,19,20,21,22,23,24,25,14,26,13', 0, 'inactive'),
(9, 24, 'Akota', 'mnop', '20,16,17,15,26,14,25,24,23,22,21\r\n', 0, 'inactive'),
(12, 25, 'Grammen', 'ssdds', '20,16,17,15,21,22,23,24,25,14,26,13,12,18,19', 4, 'inactive'),
(13, 24, 'Hanif', 'bbses', '12,13,26,14,25,24,23,22,21,15,17,16,18', 5, 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `driverinfo`
--
ALTER TABLE `driverinfo`
  ADD PRIMARY KEY (`Driver_ID`),
  ADD UNIQUE KEY `Driver_Mail_ID` (`Driver_Mail_ID`),
  ADD UNIQUE KEY `Driver_Phone` (`Driver_Phone`),
  ADD UNIQUE KEY `Driver_NID` (`Driver_NID`),
  ADD KEY `fk1` (`Company_ID`);

--
-- Indexes for table `logininfo`
--
ALTER TABLE `logininfo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Phone No` (`PhoneNo`),
  ADD UNIQUE KEY `NID No` (`NIDNo`),
  ADD UNIQUE KEY `mail_id` (`mail_id`);

--
-- Indexes for table `roadmap`
--
ALTER TABLE `roadmap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transportstand`
--
ALTER TABLE `transportstand`
  ADD PRIMARY KEY (`Stand_no`);

--
-- Indexes for table `transport_info`
--
ALTER TABLE `transport_info`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `license_no` (`license_no`),
  ADD KEY `fk2` (`company_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `driverinfo`
--
ALTER TABLE `driverinfo`
  MODIFY `Driver_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `logininfo`
--
ALTER TABLE `logininfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `roadmap`
--
ALTER TABLE `roadmap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `transportstand`
--
ALTER TABLE `transportstand`
  MODIFY `Stand_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `transport_info`
--
ALTER TABLE `transport_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `driverinfo`
--
ALTER TABLE `driverinfo`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`Company_ID`) REFERENCES `logininfo` (`id`);

--
-- Constraints for table `transport_info`
--
ALTER TABLE `transport_info`
  ADD CONSTRAINT `fk2` FOREIGN KEY (`company_id`) REFERENCES `driverinfo` (`Company_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
