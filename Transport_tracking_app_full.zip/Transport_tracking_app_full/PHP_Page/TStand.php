 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tta";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = $_POST["qry"];
$result = $conn->query($sql);

if ($result->num_rows > 0 ){
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo $row["Stand_no"]."&".$row["PlaceName"]."&". $row["Latitude"]."&".$row["Longitude"]."&".$row["Division"]."&";
    }
	echo "roadmap&";
	$sql="select *from roadmap";
	$result = $conn->query($sql);
	while($row = $result->fetch_assoc()) {
        echo $row["id"]."&".$row["start node"]."&".$row["stop node"]."&".$row["edge"]."&";
    }
	
} else {
    echo "0 results";
}
$conn->close();
?> 