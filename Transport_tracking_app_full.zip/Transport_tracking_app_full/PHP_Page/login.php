<?php
require "conn.php";
$email=$_POST["email_id"];
$user_pass=$_POST["pass_word"];
$mysql_qry= "select *from logininfo where mail_id='$email' and password ='$user_pass';"; 
$result=mysqli_query($conn ,$mysql_qry);
if(mysqli_num_rows($result)>0){
	while($row=$result->fetch_assoc()){
		echo "Welcome&".$row["username"]."&".$row["id"]."&".$row["category"];
	}
}else{
	$qry="select Driver_ID,Company_ID,Driver_Name from driverinfo where Driver_Mail_ID='$email' and Driver_Password ='$user_pass' and Driver_Approval='Yes';"; 
	$result=mysqli_query($conn ,$qry);
	if(mysqli_num_rows($result)>0){
		while($row=$result->fetch_assoc()){
			echo "Welcome&".$row["Driver_Name"]."&".$row["Driver_ID"]."&driver&".$row["Company_ID"];
		}
	}else echo "login not success";
}
$conn->close();
?>