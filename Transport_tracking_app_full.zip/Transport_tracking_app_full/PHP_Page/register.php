<?php
require "conn.php";
$email=$_POST["email_id"];
$name=$_POST["user_name"];
$pass=$_POST["pass_word"];
$phone=$_POST["phone_id"];
$nid=$_POST["nid_id"];
$category=$_POST["category_id"];

$mysql_qry= "insert into logininfo (mail_id,username,password,PhoneNo,NIDNo,category) values ('$email','$name','$pass','$phone','$nid','$category')"; 
if($conn->query($mysql_qry)===TRUE){
	echo "registration successful";
}else{
	echo "registration not successful";
}
$conn->close();
?>