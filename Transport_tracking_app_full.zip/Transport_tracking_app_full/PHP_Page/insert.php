<?php
require "conn.php";
$query= $_POST["query"];
$type=$_POST["page"];
$mysql_qry=$query;
if($type == "stoppage_insert"){
	if($conn->query($mysql_qry)===TRUE){
		echo "True";
	}else{
		echo "False";
	}
}else if ($type=="find"){
	$result=mysqli_query($conn,$mysql_qry);
	if(mysqli_num_rows($result)>0){
		while($row=$result->fetch_assoc()){
			echo $row["Stand_no"];
		}
	}
}else if ($type=="Transport_Company"){
	if($conn->query($mysql_qry)===TRUE){
		echo "True";
	}else{
		echo "False";
	}
}else{
	$qry="select Stand_no from transportstand where PlaceName='$type';";
	$result=mysqli_query($conn,$qry);
	if(mysqli_num_rows($result)>0){
		while($row=$result->fetch_assoc()){
			$mysql_qry=$row["Stand_no"];
			$qry="insert into roadmap values('0','$query','$mysql_qry','10');";
			if($conn->query($qry)===TRUE){
				echo "True";
			}
			else{
				echo "False";
			}
		}
	}
}
$conn->close();
?>