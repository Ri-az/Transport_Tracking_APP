<?php
require "conn.php";
$query= $_POST["query"];
$type=$_POST["page"];
$mysql_qry=$query;
$result=mysqli_query($conn ,$mysql_qry);
if($type == "Admin Driver Info"){
	$qry="select count(Driver_Approval) as Approval from driverinfo where Driver_Approval='No';";
	$result1=mysqli_query($conn,$qry);
	if(mysqli_num_rows($result)>0){
		while($row=$result->fetch_assoc()){
			echo $row["Company Name"]."&".$row["Driver_Name"]."&".$row["Driver_Mail_ID"]."&".$row["Driver_Phone"]."&".$row["Driver_NID"]."&";
		}
	}else{
		echo"0&0&0&0&0&";
	}
	if(mysqli_num_rows($result1)>0){
		while($row=$result1->fetch_assoc()){
			echo $row["Approval"];
		}
	}
	
}else if($type == "Admin Driver Approval"){
	$qry="select count(Driver_Approval) as Approval from driverinfo where Driver_Approval='No';";
	$result1=mysqli_query($conn,$qry);
	if(mysqli_num_rows($result)>0){
		while($row=$result->fetch_assoc()){
			echo $row["Company Name"]."&".$row["Driver_Name"]."&".$row["Driver_Mail_ID"]."&".$row["Driver_Phone"]."&".$row["Driver_NID"]."&".$row["Driver_ID"]."&";
		}
	}else{
		echo"0&0&0&0&0&";
	}	
}else if($type=="DriverApproval"){
	while($row=$result->fetch_assoc()){
		echo "Successfully updated.";
	}
}else if($type=="driverlocation"){
	while($row=$result->fetch_assoc()){
		echo "Successfully updated.";
	}
}else if($type=="driverprofileshow"){
	while($row=$result->fetch_assoc()){
		echo $row["Company Name"]."&".$row["Driver_Name"]."&".$row["Driver_Mail_ID"]."&".$row["Driver_Phone"]."&".$row["Driver_NID"];
	}
}else if($type=="stoppage"){
	while($row=$result->fetch_assoc()){
		echo $row["PlaceName"]."&".$row["Latitude"]."&".$row["Longitude"]."&";
	}
}else if($type=="user_select_transport"){
	while($row=$result->fetch_assoc()){
		echo $row["transport_name"]."&";
	}
}else if($type=="user_select_transport2"){
	while($row=$result->fetch_assoc()){
		echo $row["Location"]."&".$row["Driver_Name"]."&";
	}
}else if($type=="user_transport_info"){
	while($row=$result->fetch_assoc()){
		echo $row["transport_name"]."&".$row["road"]."&";
	}
	$qry="select Stand_no,PlaceName from transportstand;";
	$temp=mysqli_query($conn ,$qry);
	while($row=$temp->fetch_assoc()){
		echo "$&".$row["Stand_no"]."&".$row["PlaceName"]."&";
	}
}else if($type=="transport_company"){
	while($row=$result->fetch_assoc()){
		echo $row["transport_name"]."&".$row["license_no"]."&".$row["driver_id"]."&".$row["status"]."&";
	}
}else if($type=="transport_info_update"){
	while($result===TRUE){
		echo "Successfully updated.";
	}
}else if($type=="T_Driver_Info"){
	while($row=$result->fetch_assoc()){
		echo $row["Driver_Name"]."&".$row["Driver_Mail_ID"]."&".$row["Driver_Phone"]."&".$row["Driver_NID"]."&".$row["Driver_Approval"]."&";
	}
}else if(mysqli_num_rows($result)>0){
	while($row=$result->fetch_assoc()){
		echo $row["username"]."&".$row["mail_id"]."&".$row["PhoneNo"]."&".$row["NIDNo"]."&";
	}
}else{
	echo "No Entry Found!!!";
}
$conn->close();
?>