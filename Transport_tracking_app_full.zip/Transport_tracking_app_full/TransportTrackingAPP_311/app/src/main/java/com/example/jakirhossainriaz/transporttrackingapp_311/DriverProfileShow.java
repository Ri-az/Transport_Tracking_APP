package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DriverProfileShow extends AppCompatActivity {

    ArrayList value_list=new ArrayList();
    ArrayList header=new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.driver_profile_show);
        Intent intent=getIntent();
        String result=intent.getStringExtra("result");

        for(String retval: result.split("&")){
            value_list.add(retval);
        }

        TableLayout tl = (TableLayout)findViewById(R.id.Table_display);

        TextView tv0;
        TextView tv5;

        header.add("Company Name");
        header.add("Driver Name");
        header.add("Driver Mail");
        header.add("Driver Phone");
        header.add("Driver NID");

        for(int i=0; i<value_list.size()-1;i++) {
            TableRow row1 = new TableRow(this);
            tv5 = new TextView(this);
            tv0 = new TextView(this);


            tv0.setText(""+header.get(i)+" : ");
            tv0.setTextSize(22);
            tv0.setGravity(Gravity.LEFT);
            tv0.setPadding(5,2,5,2);
            tv0.setTextColor(Color.BLUE);


            tv5.setText(""+ value_list.get(i));
            tv5.setTextSize(18);
            tv5.setTextColor(Color.BLACK);
            tv5.setGravity(Gravity.RIGHT);
            tv5.setPadding(5,2,5,2);

            tl.addView(row1);
            row1.addView(tv0);
            row1.addView(tv5);
        }
    }
}
