package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText mailET,usernameET,passwordET,nidET,phoneET;
    String category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Intent intent=getIntent();
        category=intent.getStringExtra("type_user");

        mailET=(EditText)findViewById(R.id.Mail);
        usernameET=(EditText)findViewById(R.id.Username);
        passwordET=(EditText)findViewById(R.id.Password);
        phoneET=(EditText)findViewById(R.id.Phone_id);
        nidET=(EditText)findViewById(R.id.NID_id);
    }

    public void OnReg(View view){
        String email=mailET.getText().toString();
        String uname=usernameET.getText().toString();
        String pass=passwordET.getText().toString();
        String phn=phoneET.getText().toString();
        String nid=nidET.getText().toString();
        String type="register";
        String fullString=email+"~"+uname+"~"+pass+"~"+phn+"~"+nid+"~"+category;
        //Toast.makeText(getApplicationContext(),fullString,Toast.LENGTH_SHORT).show();

        SignInActivity signInActivity = new SignInActivity(this);
        signInActivity.execute(type,fullString);

    }
}
