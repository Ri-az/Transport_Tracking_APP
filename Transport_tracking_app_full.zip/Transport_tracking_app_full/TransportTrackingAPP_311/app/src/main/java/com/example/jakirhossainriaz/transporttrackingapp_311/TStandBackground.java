package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class TStandBackground extends AsyncTask<String,Void,String> {

    Context context;
    TStandBackground(Context ct){ context=ct; }
    String result = "";
    String id="";
    String type="";

    @Override
    protected String doInBackground(String... params) {
        id=params[0];
        type=params[1];
        String login_url = "http://192.168.42.149/TStand.php";
        try {
            String query = "select * from transportstand;";

            URL url = new URL(login_url);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            String post_data = URLEncoder.encode("qry", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8");

            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                result += line;
            }
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();

            return result;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        if(type.equals("admin")) {
            Intent intent = new Intent(context, AdminActivity.class);
            intent.putExtra("result", result);
            intent.putExtra("id", id);
            context.startActivity(intent);
        }else if(type.equals("user")){
            Intent intent = new Intent(context, UserActivity.class);
            intent.putExtra("result", result);
            intent.putExtra("id", id);
            context.startActivity(intent);
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}
