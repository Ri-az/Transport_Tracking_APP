package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Location_Insert extends AppCompatActivity {

    EditText start,stop1,stop2,stop3,stop4,stop5,stop6,stop7,lat,lng,div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location__insert);

        start=(EditText)findViewById(R.id.Start);
        stop1=(EditText)findViewById(R.id.Stop1);
        stop2=(EditText)findViewById(R.id.Stop2);
        stop3=(EditText)findViewById(R.id.Stop3);
        stop4=(EditText)findViewById(R.id.Stop4);
        stop5=(EditText)findViewById(R.id.Stop5);
        stop6=(EditText)findViewById(R.id.Stop6);
        stop7=(EditText)findViewById(R.id.Stop7);
        lat=(EditText)findViewById(R.id.Latitude);
        lng=(EditText)findViewById(R.id.Longitude);
        div=(EditText)findViewById(R.id.Division);
    }

    public void insert(View view){
        String st=start.getText().toString();
        Double lati=Double.parseDouble(lat.getText().toString());
        Double lngi=Double.parseDouble(lng.getText().toString());
        String sp1=stop1.getText().toString();
        String sp2=stop2.getText().toString();
        String sp3=stop3.getText().toString();
        String sp4=stop4.getText().toString();
        String sp5=stop5.getText().toString();
        String sp6=stop6.getText().toString();
        String sp7=stop7.getText().toString();
        String dvs=div.getText().toString();

        String type="stoppage_insert";
        String fullString=st+"&"+lati+"&"+lngi+"&"+dvs+"&"+sp1+"&"+sp2+"&"+sp3+"&"+sp4+"&"+sp5+"&"+sp6+"&"+sp7;
        //Toast.makeText(getApplicationContext(),fullString,Toast.LENGTH_SHORT).show();
        Database_insert database_insert=new Database_insert(this);
        database_insert.execute(type,fullString);
    }
}
