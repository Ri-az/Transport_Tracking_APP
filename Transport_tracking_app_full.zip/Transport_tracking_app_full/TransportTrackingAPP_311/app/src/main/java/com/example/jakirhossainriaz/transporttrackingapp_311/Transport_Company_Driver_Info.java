package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.graphics.Color.rgb;

public class Transport_Company_Driver_Info extends AppCompatActivity {

    String result="";
    ArrayList value_list=new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transport__company__driver__info);

        Intent intent=getIntent();
        result=intent.getStringExtra("result");

        for(String retval: result.split("&")){
            value_list.add(retval);
        }

        TableLayout tl = (TableLayout)findViewById(R.id.Table_display);
        TableRow row0 = new TableRow(this);
        row0.setBackgroundColor(rgb(255, 255, 179));

        TextView tv0 = new TextView(this);
        TextView tv1 = new TextView(this);
        TextView tv2 = new TextView(this);
        TextView tv3 = new TextView(this);
        TextView tv4 = new TextView(this);

        tv0.setText("Name");
        tv0.setTextSize(22);
        tv0.setGravity(Gravity.CENTER);
        tv0.setPadding(10,2,8,2);
        tv0.setTextColor(Color.BLUE);
        tv0.setBackgroundColor(rgb(255, 255, 179));

        tv1.setText("Email");
        tv1.setTextSize(22);
        tv1.setGravity(Gravity.CENTER);
        tv1.setPadding(10,2,8,2);
        tv1.setTextColor(Color.BLUE);
        tv1.setBackgroundColor(rgb(255, 255, 179));

        tv2.setText("Phone");
        tv2.setTextSize(22);
        tv2.setGravity(Gravity.CENTER);
        tv2.setPadding(10,2,8,2);
        tv2.setTextColor(Color.BLUE);
        tv2.setBackgroundColor(rgb(255, 255, 179));

        tv3.setText("NID ");
        tv3.setTextSize(22);
        tv3.setGravity(Gravity.CENTER);
        tv3.setPadding(10,2,8,2);
        tv3.setTextColor(Color.BLUE);
        tv3.setBackgroundColor(rgb(255, 255, 179));

        tv4.setText("Approval");
        tv4.setTextSize(22);
        tv4.setGravity(Gravity.CENTER);
        tv4.setPadding(10,2,8,2);
        tv4.setTextColor(Color.BLUE);
        tv4.setBackgroundColor(rgb(255, 255, 179));


        tl.addView(row0);
        row0.addView(tv0);
        row0.addView(tv1);
        row0.addView(tv2);
        row0.addView(tv3);
        row0.addView(tv4);

        for(int i=0,c=0; i<value_list.size();i++,c++) {
            TableRow row1 = new TableRow(this);
            TextView tv5 = new TextView(this);
            TextView tv6 = new TextView(this);
            TextView tv7=new TextView(this);
            TextView tv8 = new TextView(this);
            TextView tv9 = new TextView(this);

            tv5.setText(""+ value_list.get(i));
            tv5.setTextSize(18);
            tv5.setTextColor(Color.BLACK);
            tv5.setGravity(Gravity.LEFT);
            tv5.setPadding(10,2,8,2);

            tv6.setText(""+value_list.get(++i));
            tv6.setTextSize(18);
            tv6.setTextColor(Color.BLACK);
            tv6.setGravity(Gravity.LEFT);
            tv6.setPadding(10,2,8,2);

            tv7.setText(""+value_list.get(++i));
            tv7.setTextSize(18);
            tv7.setTextColor(Color.BLACK);
            tv7.setGravity(Gravity.LEFT);
            tv7.setPadding(10,2,8,2);

            tv8.setText(""+value_list.get(++i));
            tv8.setTextSize(18);
            tv8.setTextColor(Color.BLACK);
            tv8.setGravity(Gravity.LEFT);
            tv8.setPadding(10,2,8,2);

            tv9.setText(""+value_list.get(++i));
            tv9.setTextSize(18);
            tv9.setTextColor(Color.BLACK);
            tv9.setGravity(Gravity.LEFT);
            tv9.setPadding(10,2,8,2);

            if(c%2==1){
                row1.setBackgroundColor(rgb(255, 255, 179));
            }
            tl.addView(row1);
            row1.addView(tv5);
            row1.addView(tv6);
            row1.addView(tv7);
            row1.addView(tv8);
            row1.addView(tv9);
        }
    }
}
