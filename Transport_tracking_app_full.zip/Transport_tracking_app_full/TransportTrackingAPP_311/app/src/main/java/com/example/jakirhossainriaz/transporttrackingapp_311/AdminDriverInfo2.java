package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AdminDriverInfo2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_driver_info2);

        String result="";
        ArrayList value_list=new ArrayList();
        int approval=0;

        Intent intent=getIntent();
        result=intent.getStringExtra("result");

        //Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();

        for(String retval: result.split("&")){
            value_list.add(retval);
        }

        TableLayout tl = (TableLayout)findViewById(R.id.Table_display);

        TableRow row0 = new TableRow(this);
        row0.setBackgroundColor(Color.argb(255,254,170,12));

        TextView tv0 = new TextView(this);
        TextView tv1 = new TextView(this);
        TextView tv2 = new TextView(this);
        TextView tv3 = new TextView(this);
        TextView tv4 = new TextView(this);
        TextView tv5 = new TextView(this);

        tv0.setText("Company Name");
        tv0.setTextSize(22);
        tv0.setGravity(Gravity.CENTER);
        tv0.setPadding(5,2,5,2);
        tv0.setTextColor(Color.BLUE);

        tv1.setText("Driver Name");
        tv1.setTextSize(22);
        tv1.setGravity(Gravity.CENTER);
        tv1.setPadding(8,2,5,2);
        tv1.setTextColor(Color.BLUE);

        tv2.setText("Driver Mail");
        tv2.setTextSize(22);
        tv2.setGravity(Gravity.CENTER);
        tv2.setPadding(8,2,5,2);
        tv2.setTextColor(Color.BLUE);

        tv3.setText("Driver Phone");
        tv3.setTextSize(22);
        tv3.setGravity(Gravity.CENTER);
        tv3.setPadding(8,2,5,2);
        tv3.setTextColor(Color.BLUE);

        tv4.setText("Driver NID");
        tv4.setTextSize(22);
        tv4.setGravity(Gravity.CENTER);
        tv4.setPadding(8,2,5,2);
        tv4.setTextColor(Color.BLUE);

        tv5.setText("Approval");
        tv5.setTextSize(22);
        tv5.setGravity(Gravity.RIGHT);
        tv5.setPadding(5,2,5,2);
        tv5.setTextColor(Color.BLUE);

        tl.addView(row0);
        row0.addView(tv0);
        row0.addView(tv1);
        row0.addView(tv2);
        row0.addView(tv3);
        row0.addView(tv4);
        row0.addView(tv5);

        for(int i=0; i<value_list.size()-1;i++) {
            TableRow row1 = new TableRow(this);
            tv0 = new TextView(this);
            tv1 = new TextView(this);
            tv2 = new TextView(this);
            tv3 = new TextView(this);
            tv4 = new TextView(this);
            Switch sbtn=new Switch(this);

            tv0.setText(""+ value_list.get(i));
            tv0.setTextSize(18);
            tv0.setTextColor(Color.BLACK);
            tv0.setGravity(Gravity.LEFT);
            tv0.setPadding(5,2,5,2);

            tv1.setText(""+ value_list.get(++i));
            tv1.setTextSize(18);
            tv1.setTextColor(Color.BLACK);
            tv1.setGravity(Gravity.LEFT);
            tv1.setPadding(8,2,5,2);

            tv2.setText(""+ value_list.get(++i));
            tv2.setTextSize(18);
            tv2.setTextColor(Color.BLACK);
            tv2.setGravity(Gravity.LEFT);
            tv2.setPadding(8,2,5,2);

            tv3.setText(""+ value_list.get(++i));
            tv3.setTextSize(18);
            tv3.setTextColor(Color.BLACK);
            tv3.setGravity(Gravity.LEFT);
            tv3.setPadding(8,2,5,2);

            tv4.setText(""+ value_list.get(++i));
            tv4.setTextSize(18);
            tv4.setTextColor(Color.BLACK);
            tv4.setGravity(Gravity.LEFT);
            tv4.setPadding(8,2,5,2);

            sbtn.setId(Integer.parseInt(""+value_list.get(++i)));
            sbtn.setTextSize(18);
            sbtn.setTextColor(Color.BLACK);
            sbtn.setGravity(Gravity.LEFT);
            sbtn.setPadding(8,2,5,2);
            sbtn.setChecked(false);
            sbtn.setTextOff("No");
            sbtn.setTextOn("Yes");
            sbtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    Database_update databaseupdate =new Database_update();
                    if(compoundButton.isChecked()){
                        databaseupdate.execute("DriverApproval",""+compoundButton.getId(),"Yes");
                        Toast.makeText(getApplicationContext(),"Approved",Toast.LENGTH_LONG).show();

                    }else{
                        databaseupdate.execute("DriverApproval",""+compoundButton.getId(),"No");
                        Toast.makeText(getApplicationContext(),"Not Approved",Toast.LENGTH_LONG).show();
                    }

                }
            });


            tl.addView(row1);
            row1.addView(tv0);
            row1.addView(tv1);
            row1.addView(tv2);
            row1.addView(tv3);
            row1.addView(tv4);
            row1.addView(sbtn);
        }
    }
}
