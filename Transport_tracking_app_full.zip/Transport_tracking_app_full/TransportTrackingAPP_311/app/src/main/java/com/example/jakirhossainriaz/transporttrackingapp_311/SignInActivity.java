package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class SignInActivity extends AsyncTask<String,Void,String> {

    Context context;
    SignInActivity(Context ct){
        context=ct;
    }

    @Override
    protected String doInBackground(String... params) {

        String type = params[0];
        String reg_url = "http://192.168.42.149/register.php";
        String login_url = "http://192.168.42.149/login.php";
        if (type.equals("login")) {
            try {
                String email_id = params[1];
                String pass_word = params[2];

                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("email_id", "UTF-8") + "=" + URLEncoder.encode(email_id, "UTF-8") + "&"
                        + URLEncoder.encode("pass_word", "UTF-8") + "=" + URLEncoder.encode(pass_word, "UTF-8");

                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else if(type.equals("register")){
            String s=params[1];
            try {
                String[] value=new String[10];
                int i=0;
                for(String retval: s.split("~")){
                    value[i]=retval;
                    i++;
                }
                String email_id=value[0];
                String user_name=value[1];
                String pass_word=value[2];
                String phone=value[3];
                String nid=value[4];
                String category=value[5];

                URL url = new URL(reg_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream=httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter= new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data= URLEncoder.encode("email_id","UTF-8")+"="+URLEncoder.encode(email_id,"UTF-8")+"&"
                        +URLEncoder.encode("user_name","UTF-8")+"="+URLEncoder.encode(user_name,"UTF-8")+"&"
                        +URLEncoder.encode("pass_word","UTF-8")+"="+URLEncoder.encode(pass_word,"UTF-8")+"&"
                        +URLEncoder.encode("phone_id","UTF-8")+"="+URLEncoder.encode(phone,"UTF-8")+"&"
                        +URLEncoder.encode("nid_id","UTF-8")+"="+URLEncoder.encode(nid,"UTF-8")+"&"
                        +URLEncoder.encode("category_id","UTF-8")+"="+URLEncoder.encode(category,"UTF-8");

                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream= httpURLConnection.getInputStream();
                BufferedReader bufferedReader= new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line= bufferedReader.readLine())!=null){
                    result+=line;
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return result;
            }catch(MalformedURLException e){
                e.printStackTrace();
            }catch(IOException e){
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    protected  void onPreExecute(){

    }

    @Override
    protected void onPostExecute(String result){
        ArrayList arrayList=new ArrayList();
        for(String retval: result.split("&")){
            arrayList.add(retval);
        }

        if(result.equals("login not success")) {
            Toast.makeText(context.getApplicationContext(),"Try again with valid Email & Password",Toast.LENGTH_SHORT).show();
        }else if(arrayList.get(0).toString().equals("Welcome")){
            Toast.makeText(context.getApplicationContext(),arrayList.get(0).toString()+" "+arrayList.get(1).toString(),Toast.LENGTH_SHORT).show();
            if(arrayList.get(3).toString().equals("admin")) {
                TStandBackground tStandBackground = new TStandBackground(context);
                tStandBackground.execute(arrayList.get(2).toString(),"admin");
            }else if(arrayList.get(3).toString().equals("user")){
                TStandBackground tStandBackground = new TStandBackground(context);
                tStandBackground.execute(arrayList.get(2).toString(),"user");
            }else if(arrayList.get(3).toString().equals("driver")){
                Intent intent=new Intent(context,MapsActivity.class);
                intent.putExtra("id",arrayList.get(2).toString());
                context.startActivity(intent);
            }else if(arrayList.get(3).toString().equals("company")){
                Search_Database search_database=new Search_Database(context);
                search_database.execute("transport_company",arrayList.get(2).toString());
            }
        }else if(result.equals("registration successful")){
            Toast.makeText(context.getApplicationContext(),result,Toast.LENGTH_SHORT).show();
        }else if(result.equals("registration not successful")){
            Toast.makeText(context.getApplicationContext(),result,Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

}
