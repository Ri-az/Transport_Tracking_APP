package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

import static android.graphics.Color.rgb;

public class User_Transport_info extends AppCompatActivity {

    String result="";
    int flag=0;
    ArrayList value_list=new ArrayList();
    ArrayList road_list=new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user__transport_info);

        Intent intent=getIntent();
        result=intent.getStringExtra("result");
        for(String retval: result.split("&")){
            if(retval.equals("$")){
                flag=1;
                continue;
            }
            if(flag==0) value_list.add(retval);
            else road_list.add(retval);
        }

        TableLayout tl = (TableLayout)findViewById(R.id.Table_display);

        TableRow row0 = new TableRow(this);
        row0.setBackgroundColor(Color.WHITE);

        TextView tv0 = new TextView(this);
        TextView tv1 = new TextView(this);

        tv0.setText("Transport Name");
        tv0.setTextSize(22);
        tv0.setGravity(Gravity.CENTER);
        tv0.setPadding(5,2,5,2);
        tv0.setTextColor(Color.BLUE);
        tv0.setBackgroundColor(rgb(255, 255, 179));

        tv1.setText("Stoppage Name");
        tv1.setTextSize(22);
        tv1.setGravity(Gravity.CENTER);
        tv1.setPadding(16,2,5,2);
        tv1.setTextColor(Color.BLUE);
        tv1.setBackgroundColor(rgb(255, 255, 179));

        tl.addView(row0);
        row0.addView(tv0);
        row0.addView(tv1);

        for(int i=0,h=0; i<value_list.size();i++,h++) {
            TableRow row1 = new TableRow(this);
            TextView tv4 = new TextView(this);
            TextView tv3 = new TextView(this);

            tv4.setText(""+ value_list.get(i));
            tv4.setTextSize(18);
            tv4.setTextColor(Color.BLACK);
            tv4.setGravity(Gravity.LEFT);
            tv4.setPadding(5,2,5,2);

            String s=""+value_list.get(++i);
            String temp="";
            for(String retval: s.split(",")){
                int c=Integer.parseInt(""+retval);
                for(int j=0;j<road_list.size();j+=2){
                    if(c==Integer.parseInt(""+road_list.get(j))){
                        temp+=""+road_list.get(j+1)+"\n";
                    }
                }
            }
            tv3.setText(temp);
            tv3.setTextSize(18);
            tv3.setTextColor(Color.BLACK);
            tv3.setGravity(Gravity.LEFT);
            tv3.setPadding(16,2,5,2);


            if(h%2==1){
                row1.setBackgroundColor(rgb(255, 255, 179));
                //tv4.setBackgroundColor(rgb(255, 255, 179));
            }
            tl.addView(row1);
            row1.addView(tv4);
            row1.addView(tv3);
        }
    }
}
