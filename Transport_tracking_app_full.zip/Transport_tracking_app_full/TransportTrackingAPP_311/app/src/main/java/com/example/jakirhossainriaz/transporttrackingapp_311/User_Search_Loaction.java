package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class User_Search_Loaction extends FragmentActivity
        implements OnMapReadyCallback, GoogleMap.OnPolylineClickListener, GoogleMap.OnPolygonClickListener {

    EditText source,destination,dtns,strd;
    String src,des,stoppage;
    private GoogleMap mMap;
    private LatLng myPosition;
    ArrayList value_list = new ArrayList();
    ArrayList road_list = new ArrayList();
    ArrayList distance=new ArrayList();
    ArrayList parent=new ArrayList();
    int sorc,ds;

    class Node{
        int start=0;
        int stop=0;
        double cost=0;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_search_location);
        Intent intent=getIntent();
        stoppage=intent.getStringExtra("stoppage");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.drivermap);
        mapFragment.getMapAsync(this);

        source=(EditText)findViewById(R.id.Source);
        destination=(EditText)findViewById(R.id.Destination);
        dtns=(EditText)findViewById(R.id.Distance);
        strd=(EditText)findViewById(R.id.StRd);

        int flag=0;
        for(String retval: stoppage.split("&")){
            if(retval.equals("roadmap")){
                flag=1;
                continue;
            }
            if(flag==0) value_list.add(retval);
            else road_list.add(retval);
        }
    }

    public void search(View view){
        ArrayList<Node>[] adj_node=new ArrayList[(value_list.size()/5)+3];
        src=(source.getText().toString()).toLowerCase();
        des=(destination.getText().toString()).toLowerCase();
        sorc=0;
        ds=0;
        Queue<Integer> q = new LinkedList<>();
        for(int i=0;i<value_list.size()/5;i++){
            distance.add(10000000);
            parent.add(null);
            if(value_list.get((i*5)+1).equals(src)){
                sorc=Integer.parseInt(""+value_list.get(i*5));
            }
            if(value_list.get((i*5)+1).equals(des)){
                ds=Integer.parseInt(""+value_list.get((i*5)));
            }
            adj_node[i]=new ArrayList<Node>();
        }
        adj_node[(value_list.size()/5)]=new ArrayList<Node>();
        adj_node[(value_list.size()/5)+1]=new ArrayList<Node>();
        adj_node[(value_list.size()/5)+2]=new ArrayList<Node>();
        distance.add(10000000);
        distance.add(10000000);
        distance.add(10000000);
        parent.add(null);
        parent.add(null);
        parent.add(null);

        for(int i=0;i<road_list.size()-1;i+=4){
            Node path=new Node();
            Node path2=new Node();
            path.start=Integer.parseInt(""+road_list.get(i+1));
            path.stop=Integer.parseInt(""+road_list.get(i+2));
            path.cost=Double.parseDouble(""+road_list.get(i+3));
            adj_node[Integer.parseInt(""+road_list.get(i+1))].add(path);

            path2.start=Integer.parseInt(""+road_list.get(i+2));
            path2.stop=Integer.parseInt(""+road_list.get(i+1));
            path2.cost=Double.parseDouble(""+road_list.get(i+3));
            adj_node[Integer.parseInt(""+road_list.get(i+2))].add(path2);
        }
        q.add(sorc);
        distance.add(sorc,0);
        while(!q.isEmpty()){
            int u=q.remove();
            for(int i=0;i<adj_node[u].size();i++){
                String c=(""+adj_node[u].get(i).stop);
                String d=""+Double.parseDouble(""+(Double.parseDouble(""+distance.get(u))+Double.parseDouble(""+adj_node[u].get(i).cost)));
                if((Double.parseDouble(""+distance.get(u))+Double.parseDouble(""+adj_node[u].get(i).cost))<(Double.parseDouble(""+distance.get(Integer.parseInt(""+adj_node[u].get(i).stop))))){
                    distance.set(Integer.parseInt(c),Double.parseDouble(d));
                    q.add(Integer.parseInt(c));
                    parent.set(Integer.parseInt(c),u);
                }
            }
        }
        String road="";
        for(int i=ds;i!=sorc;){
            road+=value_list.get(((Integer.parseInt(""+i)-1)*5)+1)+" -> ";
            i=Integer.parseInt(""+parent.get(i));
        }
        road+=src;
        strd.setText(""+road);
        dtns.setText(""+distance.get(ds)+"km");
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.drivermap);
        mapFragment.getMapAsync(this);
    }

    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setTrafficEnabled(true);
        //getting LocationManager object from System Service Location_Service
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        // Creating a criteria object to retrieve provider
//        Criteria criteria = new Criteria();
//        // Getting the name of the best provider
//        String provider = locationManager.getBestProvider(criteria, true);
        String provider = "network";
        // Getting Current Location
        Location location = locationManager.getLastKnownLocation(provider);
        if (location != null) {
            // Getting latitude of the current location
            double latitude = location.getLatitude();

            // Getting longitude of the current location
            double longitude = location.getLongitude();

            // Creating a LatLng object for the current location
            LatLng latLng = new LatLng(latitude, longitude);
            myPosition = new LatLng(latitude, longitude);

            mMap.addMarker(new MarkerOptions().position(myPosition).title("My Location"));
            //mMap.moveCamera(CameraUpdateFactory.newLatLng(myPosition));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myPosition, 14));

            double prla=0,prln = 0;
            for(int i=0;i<road_list.size()-1;i+=4){
                int s=0,e=0;
                s=Integer.parseInt(""+road_list.get(i+1));
                e=Integer.parseInt(""+road_list.get(i+2));
                latitude= Double.parseDouble(""+value_list.get((s*5)-3));
                longitude=Double.parseDouble(""+value_list.get((s*5)-2));
                //Toast.makeText(this.getApplicationContext(),latitude+" "+longitude,Toast.LENGTH_LONG).show();

                myPosition = new LatLng(latitude,longitude);
                mMap.addMarker(new MarkerOptions().position(myPosition).title((String) value_list.get((s*5)-4))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));

                prla=Double.parseDouble(""+value_list.get((e*5)-3));
                prln=Double.parseDouble(""+value_list.get((e*5)-2));

                myPosition = new LatLng(prla,prln);
                mMap.addMarker(new MarkerOptions().position(myPosition).title((String) value_list.get((e*5)-4))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));

                Polyline polyline1 = googleMap.addPolyline(new PolylineOptions()
                        .clickable(true)
                        .add(
                                new LatLng(prla, prln),
                                new LatLng(latitude, longitude)));
                polyline1.setColor(Color.rgb(255, 77, 255));
                polyline1.setWidth(7);
                // Set listeners for click events.
                googleMap.setOnPolylineClickListener(this);
                googleMap.setOnPolygonClickListener(this);
            }
            String road="";
            if(parent.size()!=0){
                mMap.clear();

                for(int i=0;i<road_list.size()-1;i+=4) {
                    int s = 0, e = 0;
                    s = Integer.parseInt("" + road_list.get(i + 1));
                    e = Integer.parseInt("" + road_list.get(i + 2));
                    latitude = Double.parseDouble("" + value_list.get((s * 5) - 3));
                    longitude = Double.parseDouble("" + value_list.get((s * 5) - 2));
                    //Toast.makeText(this.getApplicationContext(),latitude+" "+longitude,Toast.LENGTH_LONG).show();

                    myPosition = new LatLng(latitude, longitude);
                    mMap.addMarker(new MarkerOptions().position(myPosition).title((String) value_list.get((s * 5) - 4))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));

                    prla = Double.parseDouble("" + value_list.get((e * 5) - 3));
                    prln = Double.parseDouble("" + value_list.get((e * 5) - 2));

                    myPosition = new LatLng(prla, prln);
                    mMap.addMarker(new MarkerOptions().position(myPosition).title((String) value_list.get((e * 5) - 4))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));

                    Polyline polyline3 = googleMap.addPolyline(new PolylineOptions()
                            .clickable(true)
                            .add(
                                    new LatLng(prla, prln),
                                    new LatLng(latitude, longitude)));
                    polyline3.setColor(Color.rgb(255, 77, 255));
                    polyline3.setWidth(7);
                }

                road="";
                latitude= Double.parseDouble(""+value_list.get(((Integer.parseInt(""+ds)-1)*5)+2));
                longitude=Double.parseDouble(""+value_list.get(((Integer.parseInt(""+ds)-1)*5)+3));

                for(int k=ds;k!=sorc;){
                    prla=Double.parseDouble(""+value_list.get(((Integer.parseInt(""+parent.get(k))-1)*5)+2));
                    prln=Double.parseDouble(""+value_list.get(((Integer.parseInt(""+parent.get(k))-1)*5)+3));
                    road+=value_list.get(((Integer.parseInt(""+k)-1)*5)+1)+" -> ";
                    k=Integer.parseInt(""+parent.get(k));
                    Polyline polyline2 = googleMap.addPolyline(new PolylineOptions()
                            .clickable(true)
                            .add(
                                    new LatLng(prla, prln),
                                    new LatLng(latitude, longitude)));
                    polyline2.setColor(Color.rgb(255, 0, 0));
                    polyline2.setWidth(7);
                    googleMap.setOnPolylineClickListener(this);
                    googleMap.setOnPolygonClickListener(this);

                    latitude= prla;
                    longitude=prln;
                }
            }
            road+=src;
            strd.setText(""+road);
        }
    }

    @Override
    public void onPolygonClick(Polygon polygon) {

    }

    @Override
    public void onPolylineClick(Polyline polyline) {

    }
}
