package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;

public class UserActivity extends FragmentActivity
        implements NavigationView.OnNavigationItemSelectedListener, OnMapReadyCallback, GoogleMap.OnPolylineClickListener, GoogleMap.OnPolygonClickListener {

    String user_id="";
    String result="";
    private GoogleMap mMap;
    private LatLng myPosition;
    ArrayList value_list=new ArrayList();
    ArrayList road_list=new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        Intent intent=getIntent();
        user_id=intent.getStringExtra("id");
        result=intent.getStringExtra("result");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.drivermap);
        mapFragment.getMapAsync(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    private void setSupportActionBar(Toolbar toolbar) {
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.user, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.User_profile) {
            String type="Profile";
            Search_Database search_database = new Search_Database(this);
            search_database.execute(type,user_id);
        } else if (id == R.id.User_Search_location) {
            Intent intent=new Intent(this,User_Search_Loaction.class);
            intent.putExtra("stoppage",result);
            intent.putExtra("id",user_id);
            startActivity(intent);
        } else if (id == R.id.User_select_transport) {
            Search_Database search_database = new Search_Database(this);
            search_database.execute("user_select_transport",result);
        } else if (id == R.id.User_transport_info) {
            Search_Database search_database = new Search_Database(this);
            search_database.execute("user_transport_info","user_transport_info");
        } else if (id == R.id.User_Logout) {
            Toast.makeText(this.getApplicationContext(),"Logout Successfully.",Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(this,MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(new Intent(this,MainActivity.class));
            finish();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setTrafficEnabled(true);
        //getting LocationManager object from System Service Location_Service
        LocationManager locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        // Creating a criteria object to retrieve provider
//        Criteria criteria = new Criteria();
//        // Getting the name of the best provider
//        String provider = locationManager.getBestProvider(criteria, true);
        // Getting Current Location
        String provider = "network";
        Location location = locationManager.getLastKnownLocation(provider);
        if (location != null) {
            // Getting latitude of the current location
            double latitude = location.getLatitude();

            // Getting longitude of the current location
            double longitude = location.getLongitude();

            // Creating a LatLng object for the current location
            LatLng latLng = new LatLng(latitude, longitude);
            myPosition = new LatLng(latitude, longitude);

            mMap.addMarker(new MarkerOptions().position(myPosition).title("My Location"));
            //mMap.moveCamera(CameraUpdateFactory.newLatLng(myPosition));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myPosition,14));int flag=0;
            for(String retval: result.split("&")){
                if(retval.equals("roadmap")){
                    flag=1;
                    continue;
                }
                if(flag==0) value_list.add(retval);
                else road_list.add(retval);
            }
            double prla=0,prln = 0;
            for(int i=0;i<road_list.size()-1;i+=4){
                int s=0,e=0;
                s=Integer.parseInt(""+road_list.get(i+1));
                e=Integer.parseInt(""+road_list.get(i+2));
                latitude= Double.parseDouble(""+value_list.get((s*5)-3));
                longitude=Double.parseDouble(""+value_list.get((s*5)-2));
                //Toast.makeText(this.getApplicationContext(),latitude+" "+longitude,Toast.LENGTH_LONG).show();

                myPosition = new LatLng(latitude,longitude);
                mMap.addMarker(new MarkerOptions().position(myPosition).title((String) value_list.get((s*5)-4))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));

                prla=Double.parseDouble(""+value_list.get((e*5)-3));
                prln=Double.parseDouble(""+value_list.get((e*5)-2));

                myPosition = new LatLng(prla,prln);
                mMap.addMarker(new MarkerOptions().position(myPosition).title((String) value_list.get((e*5)-4))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));

                Polyline polyline1 = googleMap.addPolyline(new PolylineOptions()
                        .clickable(true)
                        .add(
                                new LatLng(prla, prln),
                                new LatLng(latitude, longitude)));
                polyline1.setColor(Color.rgb(255, 77, 255));
                polyline1.setWidth(7);
                // Set listeners for click events.
                googleMap.setOnPolylineClickListener(this);
                googleMap.setOnPolygonClickListener(this);
            }
        }
    }

    @Override
    public void onPolygonClick(Polygon polygon) {

    }

    @Override
    public void onPolylineClick(Polyline polyline) {

    }
}
