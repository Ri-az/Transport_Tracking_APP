package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.CompoundButton;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class Search_Database extends AsyncTask<String,Void,String> {

    Context context;
    String type="";
    String query="";
    String temp="";
    String name="";
    String position="";
    String id="";
    Search_Database(Context ct){context=ct; }

    public Search_Database(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        context= (Context) onCheckedChangeListener;
    }

    @Override
    protected String doInBackground(String... params) {

        type=params[0];
        String search_url="http://192.168.42.149/search.php";
        if(type.equals("Profile")) {
            String user_id = params[1];
            query = "select *from logininfo where id='" + user_id + "';";
        }else if(type.equals("Admin Other")) {
            String cate = params[1];
            query = "select username,mail_id,PhoneNo,NIDNo from logininfo where category='" + cate + "';";
        }else if(type.equals("AdminTransportCompany")) {
            String cate = params[1];
            query = "select username,mail_id,PhoneNo,NIDNo from logininfo where category='" + cate + "';";

        }else if(type.equals("Admin Driver Info")) {
            String cate = params[1];
            query = "select logininfo.username as 'Company Name',driverinfo.Driver_Name,driverinfo.Driver_Mail_ID,driverinfo.Driver_Phone,driverinfo.Driver_NID from logininfo inner join driverinfo on driverinfo.Company_ID= logininfo.id where driverinfo.Driver_Approval='Yes';";
        }else if(type.equals("Admin Driver Approval")){
            String cate = params[1];
            query = "select logininfo.username as 'Company Name',driverinfo.Driver_Name,driverinfo.Driver_Mail_ID,driverinfo.Driver_Phone,driverinfo.Driver_NID,driverinfo.Driver_ID from logininfo inner join driverinfo on driverinfo.Company_ID= logininfo.id where driverinfo.Driver_Approval='No';";
        }else if(type.equals("driverprofileshow")) {
            int id =Integer.parseInt(params[1]);
            query = "select logininfo.username as 'Company Name',driverinfo.Driver_Name,driverinfo.Driver_Mail_ID,driverinfo.Driver_Phone,driverinfo.Driver_NID from logininfo inner join driverinfo on driverinfo.Company_ID= logininfo.id where driverinfo.Driver_ID='"+id+"';";
        }else if(type.equals("stoppage")) {
            String cate =params[1];
            query = "select PlaceName,Latitude,Longitude from transportstand";
        }else if(type.equals("user_search_location")) {
            String cate =params[1];
            query = "select PlaceName,Latitude,Longitude from transportstand";
        }else if(type.equals("user_select_transport")) {
            position =params[1];
            query = "select distinct transport_name from transport_info order by transport_name";
        }else if(type.equals("user_select_transport2")) {
            temp =params[1];
            name=params[2];
            position=params[3];
            query = "select driverinfo.Location, driverinfo.Driver_Name from driverinfo INNER JOIN transport_info on transport_info.driver_id=driverinfo.Driver_ID where transport_info.transport_name= '"+name+"'and transport_info.status='"+"active"+"';";
        }else if(type.equals("user_transport_info")) {
            String cate =params[1];
            query = "select distinct transport_name, road from transport_info order by transport_name";
        }else if(type.equals("transport_company")) {
            temp =params[1];
            query = "select transport_name, license_no,driver_id,status from transport_info where company_id='"+Integer.parseInt(""+temp)+"';";
        }else if(type.equals("T_Driver_Info")) {
            int id =Integer.parseInt(""+params[1]);
            query = "select Driver_Name,Driver_Mail_ID,Driver_Phone,Driver_NID,Driver_Approval from driverinfo where Company_ID='"+id+"';";
        }

        try {
            URL url = new URL(search_url);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            String post_data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8")+"&"
                    +URLEncoder.encode("page", "UTF-8") + "=" + URLEncoder.encode(type, "UTF-8");

            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
            String result = "";
            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                result += line;
            }
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
            return result;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected  void onPreExecute(){

    }

    @Override
    protected void onPostExecute(String result){
        if(type.equals("Profile")) {
            //Toast.makeText(context.getApplicationContext(),result,Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(context, Admin_Profile.class);
            intent.putExtra("result", result);
            context.startActivity(intent);
        }else if(type.equals("Admin Other")){
            Intent intent = new Intent(context, AdminOther.class);
            intent.putExtra("result", result);
            context.startActivity(intent);
        }else if(type.equals("AdminTransportCompany")){
            Intent intent = new Intent(context, AdminTransportCompany.class);
            intent.putExtra("result", result);
            context.startActivity(intent);
        }else if(type.equals("Admin Driver Info")){
            Intent intent = new Intent(context, AdminDriverInfo.class);
            intent.putExtra("result", result);
            context.startActivity(intent);
        }else if(type.equals("Admin Driver Approval")){
            Intent intent = new Intent(context, AdminDriverInfo2.class);
            intent.putExtra("result", result);
            context.startActivity(intent);
        }else if(type.equals("driverprofileshow")){
            Intent intent = new Intent(context, DriverProfileShow.class);
            intent.putExtra("result", result);
            context.startActivity(intent);
        }else if(type.equals("stoppage")){
            Intent intent = new Intent(context, AdminStoppage.class);
            intent.putExtra("resu", result);
            context.startActivity(intent);
        }else if(type.equals("user_select_transport")){
            Intent intent = new Intent(context, User_Select_Transport.class);
            intent.putExtra("result", result);
            intent.putExtra("position","");
            intent.putExtra("stoppage",position);
            context.startActivity(intent);
        }else if(type.equals("user_select_transport2")){
            Intent intent = new Intent(context, User_Select_Transport.class);
            intent.putExtra("result", temp);
            intent.putExtra("position",result);
            intent.putExtra("stoppage",position);
            context.startActivity(intent);
        }else if(type.equals("user_transport_info")){
            Intent intent = new Intent(context, User_Transport_info.class);
            intent.putExtra("result",result);
            context.startActivity(intent);
        }
        else if(type.equals("transport_company")){
            Intent intent = new Intent(context, Transport_Company.class);
            intent.putExtra("id",temp);
            intent.putExtra("result",result);
            context.startActivity(intent);
        }else if(type.equals("T_Driver_Info")) {
            Intent intent = new Intent(context, Transport_Company_Driver_Info.class);
            intent.putExtra("result",result);
            context.startActivity(intent);
        }
    }


    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}
