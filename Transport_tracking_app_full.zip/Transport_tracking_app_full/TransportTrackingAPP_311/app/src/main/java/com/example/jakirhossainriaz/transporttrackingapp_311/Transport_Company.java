package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.graphics.Color.rgb;

public class Transport_Company extends AppCompatActivity {

    String res="";
    String id="";
    String license="";
    ArrayList value_list=new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transport__company);

        Intent intent=getIntent();
        id=intent.getStringExtra("id");
        res=intent.getStringExtra("result");

        for(String retval: res.split("&")){
            value_list.add(retval);
        }

        TableLayout tl = (TableLayout)findViewById(R.id.Table_display);
        TableRow row0 = new TableRow(this);
        row0.setBackgroundColor(rgb(255, 255, 179));

        TextView tv0 = new TextView(this);
        TextView tv1 = new TextView(this);
        TextView tv2 = new TextView(this);
        TextView tv3 = new TextView(this);

        tv0.setText("Transport Name");
        tv0.setTextSize(22);
        tv0.setGravity(Gravity.CENTER);
        tv0.setPadding(5,2,5,2);
        tv0.setTextColor(Color.BLUE);
        tv0.setBackgroundColor(rgb(255, 255, 179));

        tv1.setText("Transport License");
        tv1.setTextSize(22);
        tv1.setGravity(Gravity.CENTER);
        tv1.setPadding(8,2,5,2);
        tv1.setTextColor(Color.BLUE);
        tv1.setBackgroundColor(rgb(255, 255, 179));

        tv2.setText("Driver ID");
        tv2.setTextSize(22);
        tv2.setGravity(Gravity.CENTER);
        tv2.setPadding(8,2,5,2);
        tv2.setTextColor(Color.BLUE);
        tv2.setBackgroundColor(rgb(255, 255, 179));

        tv3.setText("Status");
        tv3.setTextSize(22);
        tv3.setGravity(Gravity.CENTER);
        tv3.setPadding(8,2,5,2);
        tv3.setTextColor(Color.BLUE);
        tv3.setBackgroundColor(rgb(255, 255, 179));


        tl.addView(row0);
        row0.addView(tv0);
        row0.addView(tv1);
        row0.addView(tv2);
        row0.addView(tv3);

        for(int i=0,c=0; i<value_list.size();i+=3,c++) {
            TableRow row1 = new TableRow(this);
            TextView tv4 = new TextView(this);
            final TextView tv5 = new TextView(this);
            final TextView tv6 = new TextView(this);
            final TextView tv7=new TextView(this);
            Switch sbtn=new Switch(this);

            tv4.setText(""+ value_list.get(i));
            tv4.setTextSize(18);
            tv4.setTextColor(Color.BLACK);
            tv4.setGravity(Gravity.LEFT);
            tv4.setPadding(5,2,5,2);

            tv5.setText(""+ value_list.get(++i));
            tv5.setTextSize(18);
            tv5.setTextColor(Color.BLACK);
            tv5.setGravity(Gravity.LEFT);
            tv5.setPadding(8,2,5,2);

            tv6.setTextSize(18);
            tv6.setTextColor(Color.BLACK);
            tv6.setGravity(Gravity.LEFT);
            tv6.setPadding(8,2,5,2);

            tv7.setId(c);
            tv7.setTextSize(18);
            tv7.setTextColor(Color.BLACK);
            tv7.setGravity(Gravity.LEFT);
            tv7.setPadding(8,2,5,2);
            tv7.setCursorVisible(false);
            final int[] flag = {0};
            if(value_list.get(i+2).equals("active")){
                tv6.setText(""+value_list.get(i+1));
                tv7.setText("Active");
                flag[0] =1;
            }else{
                tv6.setText("");
                flag[0] =0;
                tv7.setText("Inactive");
            }
            tv7.setOnClickListener(new EditText.OnClickListener() {
                @Override
                public void onClick(View v) {
                    license=tv5.getText().toString();
                    if(flag[0]==0) {
                        View view= LayoutInflater.from(Transport_Company.this).inflate(R.layout.alert_transport_company,null);
                        final EditText t=(EditText) view.findViewById(R.id.D_id);
                        AlertDialog.Builder builder=new AlertDialog.Builder(Transport_Company.this);
                        builder.setMessage("Enter Driver ID")
                                .setView(view)
                                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        String f=t.getText().toString();
                                        Database_update database_update =new Database_update();
                                        database_update.execute("transport_info_update", f, license);
                                        tv6.setText(f);
                                        tv7.setText("Active");
                                        dialogInterface.dismiss();
                                        Toast.makeText(getApplicationContext(),"Active",Toast.LENGTH_LONG).show();
                                    }
                                })
                                .setNegativeButton("Cancel",null)
                                .setCancelable(false);
                        AlertDialog dialog=builder.create();
                        dialog.show();
                        flag[0]=1;
                    }else{
                        Database_update database_update =new Database_update();
                        database_update.execute("transport_info_update", "-1", license);
                        tv6.setText("");
                        tv7.setText("Inactive");
                        flag[0] =0;
                    }
                }
            });

            if(c%2==1){
                row1.setBackgroundColor(rgb(255, 255, 179));
            }
            tl.addView(row1);
            row1.addView(tv4);
            row1.addView(tv5);
            row1.addView(tv6);
            row1.addView(tv7);
        }
    }

    public void add_driver(View view1) {
        Intent intent1=new Intent(this,Transport_Company_Driver_Insert.class);
        intent1.putExtra("id",id);
        startActivity(intent1);
    }

    public void d_info(View view) {
        Search_Database search_database=new Search_Database(this);
        search_database.execute("T_Driver_Info",id);
    }

    public void profile(View view) {
        Search_Database search_database=new Search_Database(this);
        search_database.execute("Profile",id);
    }

    public void signOut(View view) {
        Toast.makeText(this.getApplicationContext(),"Logout Successfully.",Toast.LENGTH_SHORT).show();
        Intent intent=new Intent(this,MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(new Intent(this,MainActivity.class));
        finish();
    }
}
