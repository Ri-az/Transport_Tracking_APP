package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;

public class User_Select_Transport extends FragmentActivity
        implements OnMapReadyCallback, GoogleMap.OnPolylineClickListener, GoogleMap.OnPolygonClickListener {

    String result="";
    String position="";
    String stoppage="";
    String user_id="";
    ArrayList value_list=new ArrayList();
    ArrayList road_list=new ArrayList();
    ArrayList road_info=new ArrayList();
    String[] listname;
    private GoogleMap mMap;
    private LatLng myPosition;
    String name="";
    int flag=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__select__transport);

        Intent intent=getIntent();
        result=intent.getStringExtra("result");
        position=intent.getStringExtra("position");
        stoppage=intent.getStringExtra("stoppage");
        user_id=intent.getStringExtra("user_id");


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.drivermap);
        mapFragment.getMapAsync(this);

        for(String retval: result.split("&")){
            value_list.add(retval);
        }
        for(String retval: stoppage.split("&")){
            if(retval.equals("roadmap")){
                flag=1;
                continue;
            }
            if(flag==0) road_info.add(retval);
            else road_list.add(retval);
        }
        listname=new String[value_list.size()];
        for(int i=0;i<value_list.size();i++){
            listname[i] = "" + value_list.get(i);
        }

        final EditText TName=(EditText)findViewById(R.id.Tname);
        TName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder=new AlertDialog.Builder(User_Select_Transport.this);
                builder.setTitle("Select Transport");
                builder.setSingleChoiceItems(listname, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                          TName.setText(listname[i]);
                          name=listname[i];
                          dialogInterface.dismiss();
                    }
                });
                builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

                AlertDialog dialog=builder.create();
                dialog.show();
            }
        });
    }

    public void search(View view){
        Search_Database search_database = new Search_Database(this);
        search_database.execute("user_select_transport2", result,name,stoppage,user_id);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setTrafficEnabled(true);
        //getting LocationManager object from System Service Location_Service
        LocationManager locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        // Creating a criteria object to retrieve provider
//        Criteria criteria = new Criteria();
//        // Getting the name of the best provider
//        String provider = locationManager.getBestProvider(criteria, true);
        String provider = "network";
        // Getting Current Location
        Location location = locationManager.getLastKnownLocation(provider);
        if (location != null) {
            // Getting latitude of the current location
            double latitude = location.getLatitude();

            // Getting longitude of the current location
            double longitude = location.getLongitude();

            // Creating a LatLng object for the current location
            myPosition = new LatLng(latitude, longitude);

            mMap.addMarker(new MarkerOptions().position(myPosition).title("My Location"));
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myPosition,14));

            double prla=0,prln = 0;
            for(int i=0;i<road_list.size()-1;i+=4){
                int s=0,e=0;
                s=Integer.parseInt(""+road_list.get(i+1));
                e=Integer.parseInt(""+road_list.get(i+2));
                latitude= Double.parseDouble(""+road_info.get((s*5)-3));
                longitude=Double.parseDouble(""+road_info.get((s*5)-2));
                //Toast.makeText(this.getApplicationContext(),latitude+" "+longitude,Toast.LENGTH_LONG).show();

                myPosition = new LatLng(latitude,longitude);
                mMap.addMarker(new MarkerOptions().position(myPosition).title((String) road_info.get((s*5)-4))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));

                prla=Double.parseDouble(""+road_info.get((e*5)-3));
                prln=Double.parseDouble(""+road_info.get((e*5)-2));

                myPosition = new LatLng(prla,prln);
                mMap.addMarker(new MarkerOptions().position(myPosition).title((String) road_info.get((e*5)-4))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));

                Polyline polyline1 = googleMap.addPolyline(new PolylineOptions()
                        .clickable(true)
                        .add(
                                new LatLng(prla, prln),
                                new LatLng(latitude, longitude)));
                polyline1.setColor(Color.rgb(255, 77, 255));
                polyline1.setWidth(7);
                googleMap.setOnPolylineClickListener(this);
                googleMap.setOnPolygonClickListener(this);
            }
        }
        if(!position.equals("")){
            ArrayList position_list=new ArrayList();
            for(String retval: position.split("&")){
                position_list.add(retval);
            }
            for(int i=0;i<position_list.size();i+=3){
                double latitude = Double.parseDouble(""+position_list.get(i));
                double longitude = Double.parseDouble(""+position_list.get(i+1));

                myPosition= new LatLng(latitude,longitude);
                mMap.addMarker(new MarkerOptions().position(myPosition).title("Driver Name: "+position_list.get(i+2))).setIcon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN));
            }
        }
    }

    @Override
    public void onPolygonClick(Polygon polygon) {

    }

    @Override
    public void onPolylineClick(Polyline polyline) {

    }

    public void back(View view) {
        Intent intent = new Intent(this, UserActivity.class);
        intent.putExtra("result", stoppage);
        intent.putExtra("id", user_id);
        startActivity(intent);
    }
}

