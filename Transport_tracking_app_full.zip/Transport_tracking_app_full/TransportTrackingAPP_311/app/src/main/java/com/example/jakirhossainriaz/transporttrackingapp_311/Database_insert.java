package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class Database_insert extends AsyncTask<String,Void,String> {
    String type="";
    String result="";
    String query="";
    int id;
    String[] value=new String[15];

    Context context;
    Database_insert(Context ct){
        context=ct;
    }



    @Override
    protected String doInBackground(String... params) {

        type = params[0];
        String search_url = "http://192.168.42.149/insert.php";

        if (type.equals("stoppage_insert")) {
            String val = params[1];
            int i=0;
            for(String retval: val.split("&")){
                value[i]=retval;
                i++;
            }
            query = "insert into transportstand values ('" + 0 + "','" + value[0] + "','" + value[1] + "','" + value[2]+ "','" + value[3] + "');";
        }else if(type.equals("Transport_Company")){
            String val = params[1];
            int i=0;
            for(String retval: val.split("&")){
                value[i]=retval;
                i++;
            }
            id=Integer.parseInt(""+value[0]);
            query="insert into driverinfo (Company_ID,Driver_Name,Driver_Mail_ID,Driver_Password,Driver_Phone,Driver_NID,Driver_Approval) values('"+id+"','"+value[1]+"','"+value[2]+"','"+value[3]+"','"+value[4]+"','"+value[5]+"','"+"No"+"');";
        }
        if(type.equals("stoppage_insert")) {
            for (int i = 1; i < value.length; i++) {
                try {
                    URL url = new URL(search_url);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    if (i < 2) {
                        String post_data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8") + "&"
                                + URLEncoder.encode("page", "UTF-8") + "=" + URLEncoder.encode(type, "UTF-8");
                        bufferedWriter.write(post_data);
                    } else if (i == 2) {
                        query = "select Stand_no from transportstand where PlaceName='" + value[0] + "';";
                        String post_data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8") + "&"
                                + URLEncoder.encode("page", "UTF-8") + "=" + URLEncoder.encode("find", "UTF-8");
                        bufferedWriter.write(post_data);
                    } else {
                        String post_data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode("" + value[14], "UTF-8") + "&"
                                + URLEncoder.encode("page", "UTF-8") + "=" + URLEncoder.encode("" + value[i], "UTF-8");
                        bufferedWriter.write(post_data);
                    }
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                    String result = "";
                    String line = "";
                    while ((line = bufferedReader.readLine()) != null) {
                        result += line;
                    }
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    if (i == 2) {
                        value[14] = result;
                    }
                    if (i == 9) {
                        return "True";
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }else{
            try {
                URL url = new URL(search_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8") + "&"
                            + URLEncoder.encode("page", "UTF-8") + "=" + URLEncoder.encode(type, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    protected  void onPreExecute(){

    }

    @Override
    protected void onPostExecute(String result){

        if (result.equals("True")) Toast.makeText(context.getApplicationContext(), "successful", Toast.LENGTH_SHORT).show();
        else Toast.makeText(context.getApplicationContext(), "unsuccessful", Toast.LENGTH_SHORT).show();

        if(type.equals("stoppage_insert")) {
            Intent intent = new Intent(context, Location_Insert.class);
            context.startActivity(intent);
        }else if(type.equals("Transport_Company")){
            Intent intent = new Intent(context, Transport_Company_Driver_Insert.class);
            intent.putExtra("id",id);
            context.startActivity(intent);
        }
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
}
