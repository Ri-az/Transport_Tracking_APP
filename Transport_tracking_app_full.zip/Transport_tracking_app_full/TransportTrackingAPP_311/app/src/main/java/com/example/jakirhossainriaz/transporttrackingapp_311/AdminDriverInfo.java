package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

import static android.graphics.Color.rgb;

public class AdminDriverInfo extends AppCompatActivity {

    String result="";
    ArrayList value_list=new ArrayList();
    int approval=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_driver_info);

        Intent intent=getIntent();
        result=intent.getStringExtra("result");

        //Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();

        for(String retval: result.split("&")){
            value_list.add(retval);
        }

        TableLayout tl = (TableLayout)findViewById(R.id.Table_display);

        TableRow row0 = new TableRow(this);
        row0.setBackgroundColor(Color.argb(255,254,170,12));

        TextView tv0 = new TextView(this);
        TextView tv1 = new TextView(this);
        TextView tv2 = new TextView(this);
        TextView tv3 = new TextView(this);
        TextView tv4 = new TextView(this);

        tv0.setText("Company Name");
        tv0.setTextSize(22);
        tv0.setGravity(Gravity.CENTER);
        tv0.setPadding(5,2,5,2);
        tv0.setTextColor(Color.BLUE);

        tv1.setText("Driver Name");
        tv1.setTextSize(22);
        tv1.setGravity(Gravity.CENTER);
        tv1.setPadding(8,2,5,2);
        tv1.setTextColor(Color.BLUE);

        tv2.setText("Driver Mail");
        tv2.setTextSize(22);
        tv2.setGravity(Gravity.CENTER);
        tv2.setPadding(8,2,5,2);
        tv2.setTextColor(Color.BLUE);

        tv3.setText("Driver Phone");
        tv3.setTextSize(22);
        tv3.setGravity(Gravity.CENTER);
        tv3.setPadding(8,2,5,2);
        tv3.setTextColor(Color.BLUE);

        tv4.setText("Driver NID");
        tv4.setTextSize(22);
        tv4.setGravity(Gravity.CENTER);
        tv4.setPadding(8,2,5,2);
        tv4.setTextColor(Color.BLUE);



        tl.addView(row0);
        row0.addView(tv0);
        row0.addView(tv1);
        row0.addView(tv2);
        row0.addView(tv3);
        row0.addView(tv4);
        row0.setBackgroundColor(rgb(255, 255, 179));

        for(int i=0; i<value_list.size()/5;i++) {
            TableRow row1 = new TableRow(this);
            tv0 = new TextView(this);
            tv1 = new TextView(this);
            tv2 = new TextView(this);
            tv3 = new TextView(this);
            tv4 = new TextView(this);

            tv0.setText(""+ value_list.get(i*5));
            tv0.setTextSize(18);
            tv0.setTextColor(Color.BLACK);
            tv0.setGravity(Gravity.LEFT);
            tv0.setPadding(5,2,5,2);

            tv1.setText(""+ value_list.get((i*5)+1));
            tv1.setTextSize(18);
            tv1.setTextColor(Color.BLACK);
            tv1.setGravity(Gravity.LEFT);
            tv1.setPadding(8,2,5,2);

            tv2.setText(""+ value_list.get((i*5)+2));
            tv2.setTextSize(18);
            tv2.setTextColor(Color.BLACK);
            tv2.setGravity(Gravity.LEFT);
            tv2.setPadding(8,2,5,2);

            tv3.setText(""+ value_list.get((i*5)+3));
            tv3.setTextSize(18);
            tv3.setTextColor(Color.BLACK);
            tv3.setGravity(Gravity.LEFT);
            tv3.setPadding(8,2,5,2);

            tv4.setText(""+ value_list.get((i*5)+4));
            tv4.setTextSize(18);
            tv4.setTextColor(Color.BLACK);
            tv4.setGravity(Gravity.LEFT);
            tv4.setPadding(8,2,5,2);

            tl.addView(row1);
            row1.addView(tv0);
            row1.addView(tv1);
            row1.addView(tv2);
            row1.addView(tv3);
            row1.addView(tv4);
            if(i%2==1){
                row1.setBackgroundColor(rgb(255, 255, 179));
            }
        }
        tv1=(TextView)findViewById(R.id.activityset);
        tv0=(TextView)findViewById(R.id.approval);
        tv0.setText(""+value_list.get(value_list.size()-1));
        approval= Integer.parseInt((String) value_list.get(value_list.size()-1));
        if(approval>0){
            tv0.setEnabled(true);
            tv1.setVisibility(View.VISIBLE);
        }else{
            tv0.setEnabled(false);
            tv1.setVisibility(View.INVISIBLE);
        }
    }
    public void OpenDriverApproval(View view){
        String type="Admin Driver Approval";
        Search_Database search_database = new Search_Database(this);
        search_database.execute(type,"driverApproval");
    }
}
