package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText mailet,passwordet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mailet=(EditText)findViewById(R.id.Mail);
        passwordet=(EditText)findViewById(R.id.Password);
    }

    public void OnLogin(View view){
        String email=mailet.getText().toString();
        String pass= passwordet.getText().toString();
        String type="login";

        SignInActivity signInActivity = new SignInActivity(this);
        signInActivity.execute(type,email,pass);
    }

    public void OpenReg(View view){
        Intent intent=new Intent(this,RegisterActivity.class);
        intent.putExtra("type_user","user");
        startActivity(intent);
    }
}
