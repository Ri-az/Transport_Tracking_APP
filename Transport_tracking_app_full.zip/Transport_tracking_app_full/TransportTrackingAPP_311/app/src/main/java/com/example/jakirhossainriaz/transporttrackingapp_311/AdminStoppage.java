package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

import static android.graphics.Color.rgb;

public class AdminStoppage extends AppCompatActivity {

    String res="";
    ArrayList value_list=new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_stoppage);
        Intent intent=getIntent();
        res=intent.getStringExtra("resu");

        for(String retval: res.split("&")){
            value_list.add(retval);
        }

        TableLayout tl = (TableLayout)findViewById(R.id.Table_display);

        TableRow row0 = new TableRow(this);
        row0.setBackgroundColor(Color.WHITE);

        TextView tv0 = new TextView(this);
        TextView tv1 = new TextView(this);
        TextView tv2 = new TextView(this);

        tv0.setText("Place Name");
        tv0.setTextSize(22);
        tv0.setGravity(Gravity.CENTER);
        tv0.setPadding(5,2,5,2);
        tv0.setTextColor(Color.BLUE);
        tv0.setBackgroundColor(rgb(255, 255, 179));

        tv1.setText("Latitude");
        tv1.setTextSize(22);
        tv1.setGravity(Gravity.CENTER);
        tv1.setPadding(8,2,5,2);
        tv1.setTextColor(Color.BLUE);
        tv1.setBackgroundColor(rgb(255, 255, 179));

        tv2.setText("Longitude");
        tv2.setTextSize(22);
        tv2.setGravity(Gravity.CENTER);
        tv2.setPadding(8,2,5,2);
        tv2.setTextColor(Color.BLUE);
        tv2.setBackgroundColor(rgb(255, 255, 179));

        tl.addView(row0);
        row0.addView(tv0);
        row0.addView(tv1);
        row0.addView(tv2);

        for(int i=0; i<value_list.size();i++) {
            TableRow row1 = new TableRow(this);
            TextView tv4 = new TextView(this);
            TextView tv3 = new TextView(this);
            TextView tv6 = new TextView(this);
            TextView tv7 = new TextView(this);

            tv4.setText(""+ value_list.get(i));
            tv4.setTextSize(18);
            tv4.setTextColor(Color.BLACK);
            tv4.setGravity(Gravity.LEFT);
            tv4.setPadding(5,2,5,2);

            tv3.setText(""+ value_list.get(++i));
            tv3.setTextSize(18);
            tv3.setTextColor(Color.BLACK);
            tv3.setGravity(Gravity.LEFT);
            tv3.setPadding(8,2,5,2);

            tv6.setText(""+ value_list.get(++i));
            tv6.setTextSize(18);
            tv6.setTextColor(Color.BLACK);
            tv6.setGravity(Gravity.LEFT);
            tv6.setPadding(8,2,5,2);

            if(i%2==1){
                tv3.setBackgroundColor(rgb(255, 255, 179));
                tv4.setBackgroundColor(rgb(255, 255, 179));
                tv6.setBackgroundColor(rgb(255, 255, 179));
            }
            tl.addView(row1);
            row1.addView(tv4);
            row1.addView(tv3);
            row1.addView(tv6);
        }
    }

    public void add_location(View view){
        Intent intent=new Intent(this,Location_Insert.class);
        startActivity(intent);
    }
}
