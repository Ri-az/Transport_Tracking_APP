package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Admin_Profile extends AppCompatActivity {
    TextView Uname;
    TextView mail_add;
    TextView phn;
    TextView nid_no;
    String result="";
    String[] value_list= new String[10];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin__profile);
        Intent intent=getIntent();
        result=intent.getStringExtra("result");


        int i=0;
        for(String retval: result.split("&")){
            value_list[i]=retval;
            i++;
        }

        Uname=(TextView)findViewById(R.id.UserName);
        Uname.setText(value_list[0]);
        mail_add=(TextView)findViewById(R.id.Email);
        mail_add.setText(value_list[1]);
        phn=(TextView)findViewById(R.id.Phone);
        phn.setText(value_list[2]);
        nid_no=(TextView)findViewById(R.id.NID);
        nid_no.setText(value_list[3]);
    }
}
