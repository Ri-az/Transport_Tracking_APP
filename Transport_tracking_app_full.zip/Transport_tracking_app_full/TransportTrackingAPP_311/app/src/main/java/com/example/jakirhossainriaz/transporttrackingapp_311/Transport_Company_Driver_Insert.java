package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Transport_Company_Driver_Insert extends AppCompatActivity {

    String nam="";
    String email="";
    String password="";
    String phn="";
    String nid="";
    String id="";
    String s="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transport__company__driver__insert);

        Intent intent=getIntent();
        id=intent.getStringExtra("id");

    }
    public void submit(View view){
        EditText name=(EditText)findViewById(R.id.Name);
        EditText mail=(EditText)findViewById(R.id.Mail);
        EditText pass=(EditText)findViewById(R.id.Password);
        EditText phone=(EditText)findViewById(R.id.phone);
        EditText nid_no=(EditText)findViewById(R.id.NID);

        nam=name.getText().toString();
        email=mail.getText().toString();
        password=pass.getText().toString();
        phn=phone.getText().toString();
        nid=nid_no.getText().toString();
        s=id+"&"+nam+"&"+email+"&"+password+"&"+phn+"&"+nid;

        Database_insert database_insert=new Database_insert(this);
        database_insert.execute("Transport_Company",s);
    }
}
