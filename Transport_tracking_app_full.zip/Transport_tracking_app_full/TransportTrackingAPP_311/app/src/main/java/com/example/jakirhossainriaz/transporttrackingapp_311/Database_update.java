package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class Database_update extends AsyncTask<String,Void,String> {
    String type="";
    String result="";
    String query="";


    @Override
    protected String doInBackground(String... params) {

        type=params[0];
        String search_url="http://192.168.42.149/search.php";

        if(type.equals("DriverApproval")){
            int id =Integer.parseInt(params[1]);
            String val=params[2];
            query = "update driverinfo set Driver_Approval='"+val+"'where Driver_id='"+id+"';";
        }else if(type.equals("driverlocation")){
            String latlng=params[1];
            int id=Integer.parseInt(params[2]);
            query="update driverinfo set Location='"+latlng+"'where Driver_id='"+id+"';";
        }else if(type.equals("transport_info_update")){
            int id=Integer.parseInt(params[1]);
            String license=params[2];
            query="update transport_info set driver_id='"+id+"',status='"+"active"+"'where license_no='"+license+"';";
            if(id== -1){
                query="update transport_info set driver_id='"+""+"',status='"+"inactive"+"'where license_no='"+license+"';";
            }
        }

        try {
            URL url = new URL(search_url);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            String post_data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8")+"&"
                    +URLEncoder.encode("page", "UTF-8") + "=" + URLEncoder.encode(type, "UTF-8");

            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
            String result = "";
            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                result += line;
            }
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
