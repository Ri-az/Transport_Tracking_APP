package com.example.jakirhossainriaz.transporttrackingapp_311;

import android.content.Intent;
import android.graphics.Color;
import android.icu.text.MeasureFormat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AdminOther extends AppCompatActivity {

    String result="";
    ArrayList value_list=new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_other);

        Intent intent=getIntent();
        result=intent.getStringExtra("result");

        //Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();

        for(String retval: result.split("&")){
            value_list.add(retval);
        }

        TableLayout tl = (TableLayout)findViewById(R.id.Table_display);

        TableRow row0 = new TableRow(this);
        row0.setBackgroundColor(Color.argb(255,254,170,12));

        TextView tv0 = new TextView(this);
        TextView tv1 = new TextView(this);
        TextView tv5 = new TextView(this);

        tv0.setText("Name");
        tv0.setTextSize(22);
        tv0.setGravity(Gravity.CENTER);
        tv0.setPadding(5,2,5,2);
        tv0.setTextColor(Color.BLUE);

        tv1.setText("Mail Address");
        tv1.setTextSize(22);
        tv1.setGravity(Gravity.CENTER);
        tv1.setPadding(8,2,5,2);
        tv1.setTextColor(Color.BLUE);

        tv5.setText("Phone No.");
        tv5.setTextSize(22);
        tv5.setGravity(Gravity.CENTER);
        tv5.setPadding(8,2,5,2);
        tv5.setTextColor(Color.BLUE);

        tl.addView(row0);
        row0.addView(tv0);
        row0.addView(tv1);
        row0.addView(tv5);

        for(int i=0; i<value_list.size();i++) {
            TableRow row1 = new TableRow(this);
            TextView tv2 = new TextView(this);
            TextView tv3 = new TextView(this);
            TextView tv6 = new TextView(this);

            tv2.setText(""+ value_list.get(i));
            tv2.setTextSize(18);
            tv2.setTextColor(Color.BLACK);
            tv2.setGravity(Gravity.LEFT);
            tv2.setPadding(5,2,5,2);

            tv3.setText(""+ value_list.get(++i));
            tv3.setTextSize(18);
            tv3.setTextColor(Color.BLACK);
            tv3.setGravity(Gravity.LEFT);
            tv3.setPadding(8,2,5,2);

            tv6.setText(""+ value_list.get(++i));
            tv6.setTextSize(18);
            tv6.setTextColor(Color.BLACK);
            tv6.setGravity(Gravity.LEFT);
            tv6.setPadding(8,2,5,2);

            tl.addView(row1);
            row1.addView(tv2);
            row1.addView(tv3);
            row1.addView(tv6);

            ++i;
        }
    }

    public void add_admin(View view){
        Intent intent=new Intent(this,RegisterActivity.class);
        intent.putExtra("type_user","admin");
        startActivity(intent);
    }
}
